import java.util.Scanner;
public class Factorial {
    public static void main(String[] args) {
        Scanner sn=new Scanner(System.in);
        System.out.println("Enter number : ");
        int number=sn.nextInt();
        System.out.println(IteFact(number));
        System.out.println(RecFact(number));
    }

    // Iterative Factorial
    static int IteFact(int number) {
        int fact = 1;
        for (int i = 2; i <= number; i++) {
            // i start in 2 beacuse if i=1 then 1*1=1
            fact = fact * i;
        }
        return fact;
    }

    // Recursive Factorial
    static int RecFact(int number) {
        int sum=1;
        if(number>1){
            sum=number*RecFact(number-1);
        }
        
        return sum;
        //return (number > 1) ? RecFact(number - 1) * number : 1;

    }
}
